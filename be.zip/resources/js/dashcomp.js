function redirectToPage() {
    window.location.href = "/Form-Lamaran"; // Ganti dengan URL tujuan
}
